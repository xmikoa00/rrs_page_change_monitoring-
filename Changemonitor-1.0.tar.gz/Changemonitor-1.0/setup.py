# -*- encoding: utf-8 -*-

from distutils.core import setup

setup(
    name="Changemonitor",
    version="1.0",
    packages=['changemonitor'],
    maintainer="Albert Mikó",
    maintainer_email="xmikoa00@stud.fit.vutbr.cz",
    url="https://github.com/xmikoa00/rrs_page_change_monitoring-.git"
)
